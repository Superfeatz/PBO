public class Converter {
    public double getConversionRate(String from, String to) {
        if (from.equals(to)) return 1.0;

        double usdToIdr = 15000.0;
        double usdToEur = 0.85;
        double usdToJpy = 110.0;
        double usdToGbp = 0.75;

        double idrToUsd = 1 / usdToIdr;
        double eurToUsd = 1 / usdToEur;
        double jpyToUsd = 1 / usdToJpy;
        double gbpToUsd = 1 / usdToGbp;

        if (from.equals("USD")) {
            switch (to) {
                case "IDR": return usdToIdr;
                case "EUR": return usdToEur;
                case "JPY": return usdToJpy;
                case "GBP": return usdToGbp;
            }
        } else if (to.equals("USD")) {
            switch (from) {
                case "IDR": return idrToUsd;
                case "EUR": return eurToUsd;
                case "JPY": return jpyToUsd;
                case "GBP": return gbpToUsd;
            }
        } else {
            double rateFromToUsd = getConversionRate(from, "USD");
            double rateUsdToTo = getConversionRate("USD", to);
            return rateFromToUsd * rateUsdToTo;
        }

        return 1.0;
    }

    public double convert(double amount, String from, String to) {
        return amount * getConversionRate(from, to);
    }
}
